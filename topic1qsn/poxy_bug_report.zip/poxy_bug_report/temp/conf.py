DOXYFILE = r'/tmp/poxy/bug_report/temp/Doxyfile'
STYLESHEETS = []
HTML_HEADER = """<link href="poxy/poxy.css" rel="stylesheet" referrerpolicy="no-referrer" />
<script src="poxy/poxy.js"></script>
<script>initialize_theme("dark");</script>
<meta name="twitter:title" content="Calendar Tool">
<meta property="og:title" content="Calendar Tool">
<meta itemprop="name" content="Calendar Tool">
<meta name="author" content="Magpiny BO">
<meta property="article:author" content="Magpiny BO">
<meta name="description" content="A C++23 CLI tool for generating leap-year aware calendars.">
<meta name="twitter:description" content="A C++23 CLI tool for generating leap-year aware calendars.">
<meta property="og:description" content="A C++23 CLI tool for generating leap-year aware calendars.">
<meta itemprop="description" content="A C++23 CLI tool for generating leap-year aware calendars.">
<meta name="format-detection" content="telephone=no">
<meta name="generator" content="Poxy v0.20.0">
<meta name="referrer" content="strict-origin-when-cross-origin">"""
THEME_COLOR = '#22272e'
FAVICON = 'favicon-dark.png'
SHOW_UNDOCUMENTED = True
CLASS_INDEX_EXPAND_LEVELS = 3
FILE_INDEX_EXPAND_LEVELS = 3
CLASS_INDEX_EXPAND_INNER = True
SEARCH_DOWNLOAD_BINARY = False
SEARCH_DISABLED = False
LINKS_NAVBAR1 = [
('<a title="Twitter" target="_blank" href="https://twitter.com/SamuelWanjare" class="poxy-icon twitter"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 50 50" xmlns="http://www.w3.org/2000/svg" version="1.1" id="poxy-icon-twitter"><path fill="currentColor" d="M 50.0625 10.4375 C 48.214844 11.257813 46.234375 11.808594 44.152344 12.058594 C 46.277344 10.785156 47.910156 8.769531 48.675781 6.371094 C 46.691406 7.546875 44.484375 8.402344 42.144531 8.863281 C 40.269531 6.863281 37.597656 5.617188 34.640625 5.617188 C 28.960938 5.617188 24.355469 10.21875 24.355469 15.898438 C 24.355469 16.703125 24.449219 17.488281 24.625 18.242188 C 16.078125 17.8125 8.503906 13.71875 3.429688 7.496094 C 2.542969 9.019531 2.039063 10.785156 2.039063 12.667969 C 2.039063 16.234375 3.851563 19.382813 6.613281 21.230469 C 4.925781 21.175781 3.339844 20.710938 1.953125 19.941406 C 1.953125 19.984375 1.953125 20.027344 1.953125 20.070313 C 1.953125 25.054688 5.5 29.207031 10.199219 30.15625 C 9.339844 30.390625 8.429688 30.515625 7.492188 30.515625 C 6.828125 30.515625 6.183594 30.453125 5.554688 30.328125 C 6.867188 34.410156 10.664063 37.390625 15.160156 37.472656 C 11.644531 40.230469 7.210938 41.871094 2.390625 41.871094 C 1.558594 41.871094 0.742188 41.824219 -0.0585938 41.726563 C 4.488281 44.648438 9.894531 46.347656 15.703125 46.347656 C 34.617188 46.347656 44.960938 30.679688 44.960938 17.09375 C 44.960938 16.648438 44.949219 16.199219 44.933594 15.761719 C 46.941406 14.3125 48.683594 12.5 50.0625 10.4375 Z"/></svg></a>', []),
	('<a title="Toggle dark and light themes" id="poxy-theme-switch" href="javascript:void(null);" role="button" class="poxy-icon theme" onClick="toggle_theme(); return false;"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" xmlns="http://www.w3.org/2000/svg" version="1.1" id="poxy-theme-switch-img"><circle fill="currentColor" cx="185.6708" cy="183.8122" r="65.625"/><path fill="currentColor" d="M185.6708,87.5622a13.1256,13.1256,0,0,0,13.125-13.125V52.5622a13.125,13.125,0,1,0-26.25,0v21.875A13.1257,13.1257,0,0,0,185.6708,87.5622Z"/><path fill="currentColor" d="M99.051,115.7519a13.1236,13.1236,0,1,0,18.56-18.56L102.1442,81.726a13.1236,13.1236,0,0,0-18.5595,18.56Z"/><path fill="currentColor" d="M89.4208,183.8122a13.1257,13.1257,0,0,0-13.125-13.125H54.4208a13.125,13.125,0,0,0,0,26.25h21.875A13.1256,13.1256,0,0,0,89.4208,183.8122Z"/><path fill="currentColor" d="M99.051,251.8725,83.5847,267.3431a13.1236,13.1236,0,1,0,18.56,18.56l15.4663-15.4706a13.1236,13.1236,0,1,0-18.5595-18.56Z"/><path fill="currentColor" d="M185.6708,280.0622a13.1258,13.1258,0,0,0-13.125,13.125v21.875a13.125,13.125,0,0,0,26.25,0v-21.875A13.1257,13.1257,0,0,0,185.6708,280.0622Z"/><path fill="currentColor" d="M272.2907,251.8725a13.1236,13.1236,0,1,0-18.56,18.56l15.4663,15.4706a13.1236,13.1236,0,1,0,18.56-18.56Z"/><path fill="currentColor" d="M330.0458,183.8122a13.1257,13.1257,0,0,0-13.125-13.125h-21.875a13.125,13.125,0,0,0,0,26.25h21.875A13.1256,13.1256,0,0,0,330.0458,183.8122Z"/><path fill="currentColor" d="M263.0109,119.5971a13.0824,13.0824,0,0,0,9.28-3.8452l15.4663-15.4663a13.1236,13.1236,0,1,0-18.56-18.56L253.7312,97.1923a13.125,13.125,0,0,0,9.28,22.4048Z"/><path fill="currentColor" d="M456.9379,401.6714a63.97,63.97,0,0,1-14.9963,7.2055c-19.6448,6.5283-41.8787,2.9566-58.1439-9.8523a68.9311,68.9311,0,0,1-10.835-10.8339c-12.8088-16.2663-16.3806-38.5-9.8523-58.1471a63.8444,63.8444,0,0,1,7.2077-14.9931,8.8036,8.8036,0,0,0-10.1172-13.3034,87.5188,87.5188,0,1,0,110.0372,110.04A8.8,8.8,0,0,0,456.9379,401.6714Z"/></svg></a>', [])
]
LINKS_NAVBAR2 = []
FINE_PRINT = r'''
<a href="Calendar_Tool.tagfile.xml" target="_blank" type="text/xml" download>Doxygen tagfile</a>
<br><br>
Site generated using <a href="https://github.com/marzer/poxy/">Poxy</a>
'''
